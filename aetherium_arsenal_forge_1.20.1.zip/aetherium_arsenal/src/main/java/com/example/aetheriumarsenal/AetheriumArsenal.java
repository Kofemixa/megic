package com.example.aetheriumarsenal;

import com.example.aetheriumarsenal.registry.ModItems;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AetheriumArsenal.MODID)
public class AetheriumArsenal {
    public static final String MODID = "aetherium_arsenal";

    public AetheriumArsenal() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(bus);
    }
}
