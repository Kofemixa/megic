package com.example.aetheriumarsenal.item;

import com.example.aetheriumarsenal.AetheriumArsenal;
import com.example.aetheriumarsenal.registry.ModItems;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

public class AetheriumArmorMaterial implements ArmorMaterial {
    public static final AetheriumArmorMaterial INSTANCE = new AetheriumArmorMaterial();
    private static final int[] DURABILITY = {13, 15, 16, 11};
    private static final int[] DEFENSE = {3, 6, 8, 3};

    private AetheriumArmorMaterial() {}

    @Override public int getDurabilityForType(net.minecraft.world.item.ArmorItem.Type type) {
        return DURABILITY[type.getSlot().getIndex()];
    }
    @Override public int getDefenseForType(net.minecraft.world.item.ArmorItem.Type type) {
        return DEFENSE[type.getSlot().getIndex()];
    }
    @Override public int getEnchantmentValue() { return 18; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_NETHERITE; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.AETHERIUM_INGOT.get()); }
    @Override public String getName() { return AetheriumArsenal.MODID + ":aetherium"; }
    @Override public float getToughness() { return 3.0F; }
    @Override public float getKnockbackResistance() { return 0.1F; }
}
