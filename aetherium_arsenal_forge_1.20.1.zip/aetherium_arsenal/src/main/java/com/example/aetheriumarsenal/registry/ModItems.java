package com.example.aetheriumarsenal.registry;

import com.example.aetheriumarsenal.AetheriumArsenal;
import com.example.aetheriumarsenal.item.AetheriumArmorMaterial;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AetheriumArsenal.MODID);

    public static final RegistryObject<Item> AETHERIUM_INGOT = ITEMS.register("aetherium_ingot",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> AETHERIUM_SWORD = ITEMS.register("aetherium_sword",
            () -> new SwordItem(Tiers.DIAMOND, 5, -2.2F, new Item.Properties()));

    public static final RegistryObject<Item> AETHERIUM_HELMET = ITEMS.register("aetherium_helmet",
            () -> new ArmorItem(AetheriumArmorMaterial.INSTANCE, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> AETHERIUM_CHESTPLATE = ITEMS.register("aetherium_chestplate",
            () -> new ArmorItem(AetheriumArmorMaterial.INSTANCE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> AETHERIUM_LEGGINGS = ITEMS.register("aetherium_leggings",
            () -> new ArmorItem(AetheriumArmorMaterial.INSTANCE, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> AETHERIUM_BOOTS = ITEMS.register("aetherium_boots",
            () -> new ArmorItem(AetheriumArmorMaterial.INSTANCE, ArmorItem.Type.BOOTS, new Item.Properties()));

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }
}
